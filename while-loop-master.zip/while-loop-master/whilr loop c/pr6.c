#include<stdio.h>
main()
{
int limit, num, sum=0;
printf("Enetr the limit of even num:-");
scanf("%d",&limit);

num=2;

while(num <= limit)
{
if(num%2==0)
{
int cube= num * num * num;

sum += cube;
}
num++;
}
printf("sum of cubes of even num up to %d: %d\n",limit,sum);


}
