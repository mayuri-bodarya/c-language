#include<stdio.h>

main(){
	int n,m;
	
	printf("enter value for starting number :");
	scanf("%d",&n);
	
	printf("enter value for ending number :");
	scanf("%d",&m);
	
	while(n<=m){
		if(n % 4 ==0){
			printf("%d", n);
		}
		n++;
		printf("\n");
		
	}
	
}