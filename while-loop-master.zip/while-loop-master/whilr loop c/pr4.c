#include<stdio.h>

main(){
	
	int n=1, m;
	
	printf("Enter ending number:");
	scanf("%d" , &m);
	
	while(n <= m){
		if(m % 2==1){
			printf("% d",m);
		}
		m--;
		printf("\n");
	}
	
	
	
}