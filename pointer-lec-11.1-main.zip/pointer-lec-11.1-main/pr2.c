#include<stdio.h>
void main()
{
	int x,y;
	int *ptr;
	ptr = &x;
	ptr = &y;
	
	printf("Enter the value of x: ");
	scanf("%d",&x);
	printf("Enter the value of y: ");
	scanf("%d",&y);
	
	printf("\nBefore swapping:\n");
	printf("x: %d\n",x);
	printf("y: %d\n\n",*ptr);
	
	printf("After swapping:\n");
	printf("x: %d\n",y);
	printf("y: %d",x);
}
