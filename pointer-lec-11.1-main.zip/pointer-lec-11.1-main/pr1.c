#include<stdio.h>
void main()
{
	int a;
	int *ptr;
	ptr = &a;
	
	printf("Enter the any number : ");
	scanf("%d",&a);
	
	printf("A\t:%d\n",a);
	printf("ptr\t:%d\n\n",*ptr);
	
	printf("Address of A: %u\n",&a);
	printf("ptr\t:%u",ptr);
}
