#include<stdio.h>

main(){
	char str[]=" HELLO WORLD";
	int upr =strlwr(str);
	
	printf("%s",str); 
}
