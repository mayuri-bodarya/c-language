#include<stdio.h>

main(){
	char str[]=" hello world";
	int upr =strupr(str);
	
	printf("%s",str); 
}
