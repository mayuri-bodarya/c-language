#include<stdio.h>
main()
{
	char name[20];
	int s,i;
	
	printf("Enter the any name : ");
	scanf("%c",&name);
	
	for(i=name;i<=s;i++){
		
		if(){
			
		}
		else{
			
		}
	}
	
}
