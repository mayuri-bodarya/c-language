#include<stdio.h>

int div(){
	int i;
	printf("Enter any Number:- ");
	scanf("%d",&i);
	if(i % 3 == 0 && i % 5 == 0){
		printf("The number is divisable by 3 & 5 both.");
	}
	else{
		printf("The number is not divisable by 3 & 5.");
	}

}

main(){
	div();
}
