#include<stdio.h>

main(){
	int num1 = 16;
	int num2 = 7;
	int ans= num1 + num2;
	int a,b;
 
 printf("num1 value is = %d\n\n",num1);
 printf("num2 value is = %d\n\n",num2);
 printf("num1 + num2 =%d \n\n",ans);
 printf("%d + %d= %d\n\n", num1, num2,ans);
 printf("%d + %d= %d\n\n",num1,num2,num1+num2);
 printf("enter your first number : ");
 scanf("%d" ,&a);
 printf("enter your second number : ");
 scanf("%d" ,&b);
 
 printf("%d + %d =%d", a,b,a+b);
 
}
