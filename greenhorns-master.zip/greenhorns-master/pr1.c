#include<stdio.h>

main(){
	
	int f,c;
	
	printf("enter degree celcius : ");
	scanf("%d" , &c);
	
	
	f = (c* 9/5) + 32;
	printf("your fahrenheit is : %d" , f);
	}