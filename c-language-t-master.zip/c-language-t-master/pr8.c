#include<stdio.h>
main()
{
int choice;
printf("The Cafe\n\n");
printf("Enter your choice:-");
scanf("%d",&choice);

switch(choice)
{
printf("Menu:-");
printf("pizza");
printf("pasta");
printf("sendwich");
printf("sizler");
printf("burger");

case 1:
printf("Your Order PIZZA..!\n");
break;
case 2:
printf("Your Order SENDWICH..!\n");
break;
case 3:
printf("Your Order SIZLER..!\n");
break;
case 4:
printf("Your Order PASTA..!\n");
break;
case 5:
printf("Your Order BURGER..!\n");
break;

default:
printf("not available\n");
}


}
