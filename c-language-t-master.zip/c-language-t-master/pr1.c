#include<stdio.h>

main(){
	
	int a;
	
	printf("Enter Number For Check Even || Odd : ");
	scanf("%d" , &a);
	
	(a % 2 ==0)
		?   printf("your value is even")
		:	printf("your value is odd");
	
}