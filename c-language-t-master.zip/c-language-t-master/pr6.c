#include<stdio.h>

main(){
	int a,b,c;
	
	printf("enter number of a:");
	scanf("%d",&a);
	
	printf("enter number of b:");
	scanf("%d",&b);
	
	printf("enter number of c:");
	scanf("%d",&c);
	
	(a < b)
	?(a < c)?(printf("The minimum value is: %d ", a))
			:(printf("The minimum value is: %d" ,c))
			
	:(b < c)?(printf("The minimum value is:%d", b))
			:(printf("The minimum value is: %", c));
}