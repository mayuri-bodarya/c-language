#include<stdio.h>
int sum(){
	int first,second,a;
	printf("enter the first number: ");
	scanf("%d",&first);
	printf("enter the second number: ");
	scanf("%d",&second);
	a=first+second;
	printf("the addition is %d\n\n",a);
}
int sub(){
    int first,second,b;
	printf("enter the first number: ");
	scanf("%d",&first);
	printf("enter the second number: ");
	scanf("%d",&second);
	b=first-second;
	printf("the substraction is %d\n\n",b);
}
int mult(){
    int first,second,c;
	printf("enter the first num: ");
	scanf("%d",&first);
	printf("enter the second num: ");
	scanf("%d",&second);
	c=first*second;
	printf("the multiplication is %d\n\n",c);  
   
}
int div(){
    int first,second,d;
	printf("enter the first num: ");
	scanf("%d",&first);
	printf("enter the second num: ");
	scanf("%d",&second);
	d=first/second;
	printf("the devision is %d\n\n",d);  
}
  
void main(){
	int choice;

do
{
  printf("press 1 for +\n");
  printf("press 2 for -\n");
  printf("press 3 for *\n");
  printf("press 4 for /\n");
  printf("press 5 for %\n");
  printf("press 0 for Exit...\n");
  printf("enter your choice: ");
  scanf("%d",&choice);
  switch(choice){
  
  case 1:
        sum();
		break;
  case 2:
  	    sub();
		break;
  case 3:
        mult();
		break;
  case 4:
  	    div();
  	    break;
  case 0:
  	    printf("exicuted successfully...");
  	    break;
		default:
		        printf("not available...\n");
				break;
  }
}while(choice!=0);
}

