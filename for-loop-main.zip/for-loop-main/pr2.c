#include<stdio.h>

main(){
	int i=10, j=1;
	
	for(j=1; j<=i; i--){
		printf("% d",i);	
	}
}