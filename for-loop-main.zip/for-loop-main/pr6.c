#include<stdio.h>

main(){
	int i,j, sum=0,cube;
	
	printf("enter any number :");
	scanf("%d", &i);
	
	
	for(j=2;j<=i;j++){
		
		if(j%2==0){
	
		printf("even number=%d\n",j);
		cube=j*j*j;
		printf("cube is =%d \n",cube);
		sum=sum+cube;
	    }
	}
	printf("sum =%d",sum);
}