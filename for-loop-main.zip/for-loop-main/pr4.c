#include<stdio.h>

main(){
	int i,j;
	
	printf("enter the value:");
	scanf("%d", &j);
	
	for(i=j;i>=1;i--)
	{
		printf("% d",i);
	}
}