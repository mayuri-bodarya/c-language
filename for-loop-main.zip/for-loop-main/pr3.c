#include<stdio.h>

main(){
	int i=1, j;
	
	printf("enter your ending value:");
	scanf("%d",&j);
	
	for(i=1; i<=j; i++){
		printf("% d",i);
		
	}
	

}