#include<stdio.h>

int main() {
    FILE *file;
    int number;

    file = fopen("divisible_numbers.txt", "w");
    if (file == NULL) {
        printf("Unable to create file.\n");
     
    }
    printf("Numbers written to file successfully.\n");

    fclose(file);

  
}

