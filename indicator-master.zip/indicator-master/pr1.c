#include <stdio.h>
int strLength(char word[]){
	int len = 0;
	int *ptr = &len;
	int i;

	for(i=0;word[i]!=NULL;i++){
		len++;
	}
	return *ptr;
}
void main(){
	char word[50];
	printf("Enter any string: ");
	scanf("%[^\n]",&word);
	printf("name\t: %s",word);
	printf("\nstring length: %d",strLength(word));
}

