#include<stdio.h>

main(){
	int i=10, j=1;
	
	do{
		printf("% d" ,i);
		i--;		
	}while(j<=i);
}