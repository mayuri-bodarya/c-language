	#include<stdio.h>

main(){
	int i=10, j=1;
	
	do{
		printf("% d" ,j);
		j++;		
	}while(j<=i);
}