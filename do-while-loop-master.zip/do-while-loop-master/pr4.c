#include<stdio.h>

main(){
	int i=10, j=1;
	
	do{
		if(j % 2==1){
			printf("% d",j);
		}
		j++;
	}while(j<=i);
}