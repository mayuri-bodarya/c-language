#include<stdio.h>

main(){
	int i,j;
	
	printf("enter the starting value :");
	scanf("%d" ,&i);
	
	printf("enter the ending value :");
	scanf("%d" ,&j);
	
	do{
		if(i % 4 ==0){
			printf("%d", i);
		}
		i++;
		printf("\n");
	}while(i<=j);
}






	