#include<stdio.h>

main(){
	int i,j=20,ans;
	printf("enter starting number :");
	scanf("%d", &i);
	
	do{
		if(i%2==0){
			printf("% d",i);
			ans=ans+i;
		}
		i++;
	}while(i<=j);
	printf("\n\n sum of even number %d", ans);
}