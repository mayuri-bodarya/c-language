#include<stdio.h>

int main() {
    int i, j;
	
    printf("Enter the first value: ");
    scanf("%d", &i);
    printf("Enter the second value: ");
    scanf("%d", &j);
	
    int ans = sum(i, j); 
    printf("Sum is %d\n", ans);
    return 0; 
    
   
}

int sum(int a, int b) {
    int sum = a + b;
    return sum;
}

