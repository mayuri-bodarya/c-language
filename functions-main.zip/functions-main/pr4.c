#include<stdio.h>

int main() {
    int i, j;
	
    printf("Enter the first value: ");
    scanf("%d", &i);
    printf("Enter the second value: ");
    scanf("%d", &j);
	
    int ans = div(i, j); 
    printf("div is %d\n", ans);
    return 0; 
}

int div(int a, int b) {
    int div = a / b;
    return div;
}

