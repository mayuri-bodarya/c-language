#include<stdio.h>

main(){
	int age;
	
	printf("Enter The Age :\n");
	scanf("%d", &age);
	
	if(age>=1){
		printf("The Age Is You Have Entered Is Yonger...");
	}
	
	else if(age>=13){
		printf("The Age Is You Have Entered Is Teenagers...");
	}
	
	else if(age>=20){
		printf("The Age Is You Have Entered Is Adult...");
	}
	
	else if(age>=65){
		printf("The Age Is You Have Entered Is Senior...");
	}
	
	else{
		printf("The Age You Have Entered Is Invalid...");
	}
}