#include<stdio.h>

main(){
	float totalmarks;
	float percentage;
	
	printf("Ener your Total marks:- ");
	scanf("%f",&totalmarks);
	
	percentage=(totalmarks*100)/500;
	
	printf("percentage:- %f \n",percentage);
	
	if(percentage>=90){
		printf("A Grade");
	}

	else if(percentage>=80){
		printf("B Grade");
	}
	
	else if(percentage>=70){
		printf("C Grade");
	}
	
	else if(percentage>=60){
		printf("D Grade");
	}
	
	else{
		printf("Failed..");
	}
}