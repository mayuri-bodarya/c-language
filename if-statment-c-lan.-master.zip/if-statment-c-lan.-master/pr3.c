#include<stdio.h>

main(){
	
	int number;
	
	printf("Enter The Value Of Number :\n");
	scanf("%d",&number);
	
	if(number<0){
		printf("The Number You Have Entered Is NEGETIVE...!!");
	}
	
	else if(number==0){
		printf("The Number You Have Entered Is ZERO...!!");
	}
	
	else{
		printf("The Number You Have POSITIVE...!");
	}
	
}