#include<stdio.h>

main(){
	
	int a;
	
	printf("Enter Number For Check Even || Odd : \n");
	scanf("%d" , &a);
	
	if(a % 2 ==0){
		printf("your value is even");
	}	
	
	else{
		printf("your value is odd");
	}	
}