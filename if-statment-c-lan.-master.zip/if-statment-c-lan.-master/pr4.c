#include<stdio.h>

main(){
	int a;
	
	printf("Enter Your Age : \n");
	scanf("%d",&a);
	
	if(a <=0){
		printf("Plese Enter Valid Age");
	}
	
	else if(a >=18){
		printf("Your Are Eligible For Vote");
	}
	
	else{
		printf("Your Are Not Eligible For Vote");
	}
}